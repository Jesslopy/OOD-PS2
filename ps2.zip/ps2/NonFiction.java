/*
 * creates a non-fiction subclass for books
 *
 * --your name--
 */

public class NonFiction extends Book
{

}
