/*
 * creates an enumerated data type for genre
 *
 * --your name--
 */

public enum Genre 
{

}


