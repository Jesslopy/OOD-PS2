/*
 * creates a comparator for sorting books by rating 
 *
 * --your name--
 */

import java.util.Comparator;

public class BookRatingComparator implements Comparator<Book>
{

}	
