/*
 * creates a comparator for sorting books by color
 *
 * --your name--
 */

import java.util.Comparator;

public class BookColorComparator implements Comparator<Book>
{

}	
