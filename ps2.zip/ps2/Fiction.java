/*
 * creates a fiction subclass for books
 *
 * --your name--
 */

public class Fiction extends Book
{

}
