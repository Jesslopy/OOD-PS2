/*
 * creates a book class
 *
 * --your name--
 */

import java.util.Set;
import java.util.LinkedHashSet;

public abstract class Book implements Comparable<Book>
{
	// copy code from Assignment 1 here and then add new items 
}
